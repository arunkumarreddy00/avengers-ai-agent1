OPTIONAL ORIGINAL VOICE FILES

The application uses browser Speech Synthesis when custom files are absent.
To use your own licensed or self-recorded narration, add MP3 files with these names:

reactor-online.mp3
assemble.mp3
team-online.mp3
striker.mp3
thunder.mp3
titan.mp3
sentinel.mp3
shadow.mp3
webforge.mp3
oracle.mp3
nova.mp3

Do not add cloned celebrity voices or third-party audio without permission.
