OPTIONAL ORIGINAL AGENT IMAGES

The application already includes CSS hologram fallback avatars.
To use your own licensed or self-created images, add:

striker.jpg
thunder.jpg
titan.jpg
sentinel.jpg
shadow.jpg
webforge.jpg
oracle.jpg
nova.jpg
team-banner.jpg

Do not add copyrighted movie stills, logos, or third-party assets unless you have permission.
