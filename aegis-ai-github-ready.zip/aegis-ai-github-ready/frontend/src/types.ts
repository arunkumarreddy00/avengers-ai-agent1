export type AgentStatus = 'ONLINE' | 'WAITING' | 'ANALYZING' | 'WORKING' | 'COMPLETED'

export interface Agent {
  id: string
  name: string
  role: string
  symbol: string
  color: string
  accent: string
  intro: string
  capabilities: string[]
}

export interface MissionLog {
  id: string
  agent: string
  text: string
  status: AgentStatus
}
