import type { Agent } from './types'

export const agents: Agent[] = [
  { id: 'striker', name: 'STRIKER', role: 'Mission Commander', symbol: 'ST', color: '#ff3b30', accent: '#ffd166', intro: 'I am Striker. Tactical systems online. I will coordinate the mission.', capabilities: ['Strategy', 'Coordination', 'Final report'] },
  { id: 'thunder', name: 'THUNDER', role: 'Research Intelligence', symbol: 'TH', color: '#55d9ff', accent: '#d8f5ff', intro: 'I am Thunder. Intelligence systems activated. I will uncover the information you need.', capabilities: ['Research', 'Trends', 'Discovery'] },
  { id: 'titan', name: 'TITAN', role: 'Heavy Problem Solver', symbol: 'TI', color: '#76ff7a', accent: '#d7ffb8', intro: 'I am Titan. Power systems online. Give me the hardest task.', capabilities: ['Breakdown', 'Execution', 'Error analysis'] },
  { id: 'sentinel', name: 'SENTINEL', role: 'Planning Leader', symbol: 'SE', color: '#4c7dff', accent: '#ff6b6b', intro: 'I am Sentinel. Strategy protocol activated. I will organize the mission step by step.', capabilities: ['Planning', 'Priorities', 'Leadership'] },
  { id: 'shadow', name: 'SHADOW', role: 'Security Analyst', symbol: 'SH', color: '#ff426d', accent: '#9b9ba5', intro: 'I am Shadow. Security systems online. I will detect risks and protect the operation.', capabilities: ['Security', 'Privacy', 'Risk checks'] },
  { id: 'webforge', name: 'WEBFORGE', role: 'Development Agent', symbol: 'WF', color: '#ff4d4d', accent: '#5a8cff', intro: 'I am WebForge. Development systems activated. I will build, test, and debug the solution.', capabilities: ['Frontend', 'Backend', 'Debugging'] },
  { id: 'oracle', name: 'ORACLE', role: 'Reasoning Analyst', symbol: 'OR', color: '#b66cff', accent: '#ff9f43', intro: 'I am Oracle. Analytical systems online. I will explore every possible solution.', capabilities: ['Reasoning', 'Analysis', 'Options'] },
  { id: 'nova', name: 'NOVA', role: 'Creative Designer', symbol: 'NO', color: '#ff4fa3', accent: '#bd69ff', intro: 'I am Nova. Creative systems activated. I will transform ideas into powerful experiences.', capabilities: ['UI design', 'Branding', 'Content'] },
]
