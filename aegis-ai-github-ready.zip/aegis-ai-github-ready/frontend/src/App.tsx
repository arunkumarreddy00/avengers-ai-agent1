import { useEffect, useMemo, useRef, useState } from 'react'
import { agents } from './data'
import type { Agent, MissionLog } from './types'

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

type VoiceProfile = {
  rate: number
  pitch: number
  gender: 'male' | 'female' | 'any'
  preferredNames: string[]
}

type AudioEngine = {
  context?: AudioContext
  hum?: OscillatorNode
  humGain?: GainNode
}

const engine: AudioEngine = {}


let assembleTrack: HTMLAudioElement | undefined

function getAssembleTrack() {
  if (!assembleTrack) {
    assembleTrack = new Audio('/media/assemble-audio.mp3')
    assembleTrack.preload = 'auto'
  }
  return assembleTrack
}

function unlockAssembleTrack() {
  const audio = getAssembleTrack()
  audio.volume = 0
  audio.currentTime = 0
  void audio.play().then(() => {
    audio.pause()
    audio.currentTime = 0
    audio.volume = 0.95
  }).catch(() => {
    audio.volume = 0.95
  })
}

async function playAssembleTrack(muted: boolean) {
  if (muted) return false
  const audio = getAssembleTrack()
  audio.pause()
  audio.currentTime = 0
  audio.volume = 0.95
  return await new Promise<boolean>((resolve) => {
    let settled = false
    const finish = (ok: boolean) => {
      if (settled) return
      settled = true
      audio.onended = null
      audio.onerror = null
      resolve(ok)
    }
    audio.onended = () => finish(true)
    audio.onerror = () => finish(false)
    audio.play().catch(() => finish(false))
    window.setTimeout(() => finish(false), 12000)
  })
}

function stopAssembleTrack() {
  if (!assembleTrack) return
  assembleTrack.pause()
  assembleTrack.currentTime = 0
}

const voiceProfiles: VoiceProfile[] = [
  { rate: 0.64, pitch: 0.62, gender: 'male', preferredNames: ['Microsoft Mark', 'Microsoft David', 'Google UK English Male', 'Daniel', 'Alex'] },
  { rate: 0.57, pitch: 0.48, gender: 'male', preferredNames: ['Microsoft David', 'Google UK English Male', 'Daniel', 'Alex'] },
  { rate: 0.56, pitch: 0.42, gender: 'male', preferredNames: ['Microsoft David', 'Microsoft Mark', 'Google UK English Male', 'Alex'] },
  { rate: 0.66, pitch: 0.64, gender: 'male', preferredNames: ['Microsoft Mark', 'Microsoft David', 'Google US English', 'Alex'] },
  { rate: 0.67, pitch: 0.84, gender: 'female', preferredNames: ['Microsoft Zira', 'Google UK English Female', 'Samantha', 'Victoria'] },
  { rate: 0.72, pitch: 0.90, gender: 'male', preferredNames: ['Microsoft Mark', 'Google US English', 'Alex'] },
  { rate: 0.60, pitch: 0.52, gender: 'male', preferredNames: ['Microsoft David', 'Daniel', 'Google UK English Male', 'Alex'] },
  { rate: 0.65, pitch: 0.88, gender: 'female', preferredNames: ['Microsoft Zira', 'Google UK English Female', 'Samantha', 'Victoria'] },
]

const femaleHints = ['zira', 'female', 'samantha', 'victoria', 'karen', 'moira', 'tessa', 'veena']
const maleHints = ['david', 'mark', 'male', 'daniel', 'alex', 'george', 'ravi']

function chooseVoice(voices: SpeechSynthesisVoice[], profile: VoiceProfile) {
  const english = voices.filter(v => v.lang.toLowerCase().startsWith('en'))
  const pool = english.length ? english : voices
  for (const wanted of profile.preferredNames) {
    const found = pool.find(v => v.name.toLowerCase().includes(wanted.toLowerCase()))
    if (found) return found
  }
  const hints = profile.gender === 'female' ? femaleHints : profile.gender === 'male' ? maleHints : []
  return pool.find(v => hints.some(h => v.name.toLowerCase().includes(h))) || pool[0]
}

async function speakSynthetic(text: string, muted: boolean, profileIndex = 0, force = false) {
  if ((!force && muted) || !('speechSynthesis' in window)) return
  const synth = window.speechSynthesis
  synth.resume()
  const profile = voiceProfiles[Math.min(profileIndex, voiceProfiles.length - 1)] || voiceProfiles[0]
  await new Promise<void>((resolve) => {
    const line = new SpeechSynthesisUtterance(text)
    line.volume = 1
    line.rate = profile.rate
    line.pitch = profile.pitch
    line.onend = () => resolve()
    line.onerror = () => resolve()
    let played = false
    const play = () => {
      if (played) return
      played = true
      const selected = chooseVoice(synth.getVoices(), profile)
      if (selected) line.voice = selected
      synth.speak(line)
    }
    if (synth.getVoices().length) play()
    else {
      synth.addEventListener('voiceschanged', play, { once: true })
      window.setTimeout(play, 500)
    }
  })
}

async function speakLine(key: string, text: string, muted: boolean, profileIndex = 0, force = false) {
  if ((!force && muted)) return
  // Optional premium royalty-free voice slot. Add your own legal MP3 files under public/audio/voices/.
  const customPath = `/audio/voices/${key}.mp3`
  const audio = new Audio(customPath)
  audio.volume = 0.98
  const customPlayed = await new Promise<boolean>((resolve) => {
    let settled = false
    const finish = (value: boolean) => { if (!settled) { settled = true; resolve(value) } }
    audio.onended = () => finish(true)
    audio.onerror = () => finish(false)
    audio.play().then(() => undefined).catch(() => finish(false))
    window.setTimeout(() => finish(false), 500)
  })
  if (!customPlayed) await speakSynthetic(text, muted, profileIndex, force)
}

function speak(text: string, muted: boolean, profileIndex = 0, force = false) {
  void speakSynthetic(text, muted, profileIndex, force)
}

function ensureAudio() {
  const AudioCtx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
  if (!AudioCtx) return
  if (!engine.context) engine.context = new AudioCtx()
  void engine.context.resume()
}

function startHum() {
  ensureAudio()
  if (!engine.context || engine.hum) return
  const osc = engine.context.createOscillator()
  const gain = engine.context.createGain()
  osc.type = 'sine'
  osc.frequency.value = 47
  gain.gain.value = 0.028
  osc.connect(gain).connect(engine.context.destination)
  osc.start()
  engine.hum = osc
  engine.humGain = gain
}

function stopHum() {
  try { engine.hum?.stop() } catch { /* no-op */ }
  engine.hum = undefined
  engine.humGain = undefined
}

function sfx(type: 'boot' | 'impact' | 'activate') {
  ensureAudio()
  if (!engine.context) return
  const ctx = engine.context
  const now = ctx.currentTime
  const osc = ctx.createOscillator()
  const gain = ctx.createGain()
  osc.type = type === 'impact' ? 'sawtooth' : 'sine'
  osc.frequency.setValueAtTime(type === 'impact' ? 92 : type === 'activate' ? 360 : 180, now)
  osc.frequency.exponentialRampToValueAtTime(type === 'impact' ? 32 : type === 'activate' ? 790 : 310, now + (type === 'impact' ? 0.65 : 0.22))
  gain.gain.setValueAtTime(type === 'impact' ? 0.11 : 0.045, now)
  gain.gain.exponentialRampToValueAtTime(0.0001, now + (type === 'impact' ? 0.72 : 0.28))
  osc.connect(gain).connect(ctx.destination)
  osc.start(now)
  osc.stop(now + (type === 'impact' ? 0.75 : 0.3))
}

function Reactor({ compact = false, surge = false }: { compact?: boolean; surge?: boolean }) {
  return <div className={`reactor ${compact ? 'compact' : ''} ${surge ? 'surge' : ''}`}>
    <div className="reactor-orbit orbit-a" /><div className="reactor-orbit orbit-b" />
    <div className="ring ring-one" /><div className="ring ring-two" /><div className="ring ring-three" />
    <div className="reactor-flare" /><div className="core"><span>A</span></div>
  </div>
}

function ParticleField() {
  return <div className="particles">{Array.from({ length: 58 }).map((_, i) => <i key={i} style={{ '--x': `${(i * 37) % 100}%`, '--y': `${(i * 61) % 100}%`, '--d': `${3 + (i % 8)}s`, '--delay': `${-(i % 9)}s` } as React.CSSProperties} />)}</div>
}

function HoloAvatar({ agent, size = 'large' }: { agent: Agent; size?: 'small' | 'large' }) {
  const [imageMissing, setImageMissing] = useState(false)
  const imagePath = `/images/agents/${agent.id}.jpg`
  return <div className={`holo-avatar ${size}`} style={{ '--agent': agent.color, '--accent': agent.accent } as React.CSSProperties}>
    {!imageMissing && <img className="hero-photo" src={imagePath} alt={`${agent.name} cinematic portrait`} onError={() => setImageMissing(true)} />}
    {imageMissing && <div className={`hero-bust hero-${agent.id}`}>
      <div className="hero-aura" />
      <div className="hero-head"><i /><b /></div>
      <div className="hero-neck" />
      <div className="hero-body"><span className="hero-core">{agent.symbol}</span></div>
      <div className="hero-shoulder left" /><div className="hero-shoulder right" />
      <div className="hero-special" />
    </div>}
    <div className="avatar-scan" />
    <div className="photo-vignette" />
  </div>
}


function TeamBackdrop() {
  const [missing, setMissing] = useState(false)
  return <div className="team-backdrop">
    {!missing && <img src="/images/agents/team-banner.jpg" alt="Aegis agent team cinematic banner" onError={() => setMissing(true)} />}
    <div className={`team-backdrop-fallback ${missing ? 'show' : ''}`} />
    <div className="team-backdrop-overlay" />
    <div className="team-backdrop-light" />
  </div>
}

function HudFrame() {
  return <><div className="hud-grid" /><div className="hud-vignette" /><div className="hud-corner tl">AEGIS // 01</div><div className="hud-corner tr">LIVE SYSTEM FEED</div><div className="hud-corner bl">SECURE CHANNEL</div><div className="hud-corner br">EARTH // COMMAND</div></>
}

function TeamFormation({ active, final = false }: { active: number; final?: boolean }) {
  return <div className={`team-formation ${final ? 'formation-final' : ''}`}>
    <div className="formation-core"><Reactor compact surge /></div>
    {agents.map((agent, index) => <div key={agent.id} className={`formation-slot slot-${index} ${index <= active || final ? 'revealed' : ''} ${index === active ? 'is-active' : ''}`} style={{ '--agent': agent.color, '--accent': agent.accent } as React.CSSProperties}>
      <div className="slot-beam" /><HoloAvatar agent={agent} size="small" /><strong>{agent.name}</strong><small>{index <= active || final ? 'ONLINE' : 'STANDBY'}</small>
    </div>)}
  </div>
}

function Intro({ muted, onDone, onEnableVoice }: { muted: boolean; onDone: () => void; onEnableVoice: () => void }) {
  const [started, setStarted] = useState(false)
  const [phase, setPhase] = useState(0)
  const [active, setActive] = useState(-1)
  const skipped = useRef(false)

  useEffect(() => {
    if (!started) return
    skipped.current = false
    const run = async () => {
      window.speechSynthesis?.cancel()
      startHum()
      sfx('boot')
      await wait(900); if (skipped.current) return
      setPhase(1); await speakLine('system-online', 'System initialization started. Secure command channel established.', muted, 0)
      await wait(650); if (skipped.current) return
      setPhase(2); sfx('boot'); await speakLine('reactor-online', 'Core reactor synchronized. Aegis command center online.', muted, 0)
      await wait(900); if (skipped.current) return
      setPhase(3); sfx('impact')
      void playAssembleTrack(muted)
      await speakLine('assemble', 'Agents... assemble.', muted, 1)
      await wait(1400); if (skipped.current) return
      setPhase(4)
      for (let i = 0; i < agents.length; i++) {
        if (skipped.current) return
        setActive(i); sfx('activate')
        await speakLine(agents[i].id, agents[i].intro, muted, i)
        await wait(520)
      }
      if (skipped.current) return
      setPhase(5); sfx('impact')
      await speakLine('team-online', 'All agents are online. Commander... your mission awaits.', muted, 0)
      await wait(1750); stopHum(); onDone()
    }
    void run()
    return () => { skipped.current = true; window.speechSynthesis?.cancel(); stopAssembleTrack(); stopHum() }
  }, [started])

  const skip = () => { skipped.current = true; window.speechSynthesis?.cancel(); stopAssembleTrack(); stopHum(); onDone() }

  if (!started) return <main className="intro-screen gate-screen">
    <ParticleField /><div className="scanlines" /><HudFrame />
    <TeamBackdrop />
    <div className="gate-panel">
      <div className="gate-kicker">STARK-CLASS COMMAND INTERFACE</div>
      <Reactor surge />
      <h1>AEGIS <em>AI</em></h1>
      <p>Eight specialized agents. One command center.</p>
      <div className="gate-actions"><button className="primary intro-start" onClick={() => { onEnableVoice(); ensureAudio(); unlockAssembleTrack(); sfx('impact'); setStarted(true) }}>ENTER COMMAND CENTER</button><button className="ghost-button voice-test" onClick={() => { onEnableVoice(); ensureAudio(); sfx('boot'); speak('Voice test successful. Command system online.', false, 0, true) }}>TEST VOICE</button></div>
      <small className="gate-note">Click to unlock browser audio and begin the cinematic sequence</small>
    </div>
  </main>


  return <main className={`intro-screen phase-${phase}`}>
    <TeamBackdrop /><ParticleField /><div className="scanlines" /><HudFrame />
    <button className="ghost-button skip" onClick={skip}>SKIP INTRO</button>
    {phase === 0 && <div className="intro-copy boot-sequence"><div className="terminal-lines"><span>AUTHENTICATING COMMANDER...</span><span>OPENING SECURE CHANNEL...</span><span>LOADING AEGIS AI CORE...</span></div></div>}
    {phase === 1 && <div className="intro-copy protocol"><div className="tiny">INITIALIZING SECURE PROTOCOL</div><h1>AEGIS <em>AI</em></h1><div className="loader"><span /></div><p>COMMAND NETWORK // BOOT SEQUENCE</p></div>}
    {phase === 2 && <div className="intro-copy reactor-scene"><div className="reactor-caption top">ARC REACTOR LINK ESTABLISHED</div><Reactor surge /><div className="reactor-caption bottom">POWER CORE STABLE // 100%</div></div>}
    {phase === 3 && <div className="intro-copy assemble"><div className="assemble-line" /><h1>AGENTS</h1><h2>ASSEMBLE</h2><div className="assemble-line" /></div>}
    {phase === 4 && active >= 0 && <div className="roster-stage">
      <TeamFormation active={active} />
      <div className="active-agent-panel" style={{ '--agent': agents[active].color, '--accent': agents[active].accent } as React.CSSProperties}>
        <HoloAvatar agent={agents[active]} />
        <div className="active-copy"><small>AGENT {String(active + 1).padStart(2, '0')} // ACTIVATION CONFIRMED</small><h2>{agents[active].name}</h2><p>{agents[active].role}</p><div className="power"><span /></div><b>ONLINE</b></div>
      </div>
    </div>}
    {phase === 5 && <div className="final-stage"><div className="final-wide-glow" /><TeamFormation active={agents.length - 1} final /><div className="final-copy"><small>TEAM SYNCHRONIZATION COMPLETE</small><h1>ALL AGENTS ONLINE</h1><p>COMMANDER, YOUR MISSION AWAITS.</p></div></div>}
  </main>
}

function AgentCard({ agent, chosen, onToggle }: { agent: Agent; chosen: boolean; onToggle: () => void }) {
  return <article className={`agent-card ${chosen ? 'chosen' : ''}`} style={{ '--agent': agent.color, '--accent': agent.accent } as React.CSSProperties}>
    <div className="card-top"><HoloAvatar agent={agent} size="small" /><span className="status-dot">ONLINE</span></div>
    <h3>{agent.name}</h3><p>{agent.role}</p>
    <div className="tags">{agent.capabilities.map((x) => <span key={x}>{x}</span>)}</div>
    <button onClick={onToggle}>{chosen ? 'DEPLOYED' : 'DEPLOY AGENT'}</button>
  </article>
}

function App() {
  const [showIntro, setShowIntro] = useState(true)
  const [muted, setMuted] = useState(localStorage.getItem('aegis-muted') === 'yes')
  const [selected, setSelected] = useState<string[]>(['striker'])
  const [mission, setMission] = useState('')
  const [logs, setLogs] = useState<MissionLog[]>([])
  const [busy, setBusy] = useState(false)
  const [report, setReport] = useState('')
  const [buildBusy, setBuildBusy] = useState(false)
  const [buildError, setBuildError] = useState('')
  const [websiteBuild, setWebsiteBuild] = useState<{ title: string; summary: string; files: string[]; download_url: string; mode: string } | null>(null)
  const [settings, setSettings] = useState(false)
  const [clock, setClock] = useState(new Date())
  useEffect(() => { const t = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(t) }, [])
  const team = useMemo(() => agents.filter(a => selected.includes(a.id)), [selected])
  const finishIntro = () => setShowIntro(false)
  const enableVoice = () => { setMuted(false); localStorage.setItem('aegis-muted', 'no'); window.speechSynthesis?.resume() }
  const toggleMute = () => { const v = !muted; setMuted(v); localStorage.setItem('aegis-muted', v ? 'yes' : 'no'); if (v) window.speechSynthesis?.cancel(); else window.setTimeout(() => speak('Voice narration enabled.', false, 0, true), 0) }
  const toggle = (id: string) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id])
  const assemble = () => setSelected(agents.map(a => a.id))

  const execute = async () => {
    if (!mission.trim() || !team.length || busy) return
    setBusy(true); setLogs([]); setReport('')
    try {
      const r = await fetch(`${API}/api/missions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: mission, agent_ids: team.map(a => a.id) }) })
      const created = await r.json()
      const exec = await fetch(`${API}/api/missions/${created.id}/execute`, { method: 'POST' })
      const result = await exec.json()
      for (const item of result.logs) { setLogs(x => [...x, item]); speak(`${item.agent}. ${item.text}`, muted, 1); await wait(650) }
      setReport(result.report)
    } catch {
      const localLogs = team.map((a, i) => ({ id: `${Date.now()}-${i}`, agent: a.name, text: `${a.role} completed an offline mock analysis for: ${mission}`, status: 'COMPLETED' as const }))
      for (const item of localLogs) { setLogs(x => [...x, item]); await wait(520) }
      setReport(`MISSION REPORT\n\nObjective: ${mission}\n\n${localLogs.map(x => `• ${x.agent}: ${x.text}`).join('\n')}\n\nSTRIKER FINAL STATUS: Mission plan assembled.`)
    } finally { setBusy(false) }
  }

  const buildWebsite = async () => {
    if (!mission.trim() || !team.length || buildBusy) return
    setBuildBusy(true); setBuildError(''); setWebsiteBuild(null)
    try {
      const response = await fetch(`${API}/api/websites/build`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: mission, agent_ids: team.map(a => a.id) })
      })
      const result = await response.json()
      if (!response.ok) throw new Error(result.detail || 'Website generation failed')
      setWebsiteBuild(result)
      setReport(`WEBSITE BUILD COMPLETE\n\n${result.title}\n${result.summary}\n\nGenerated files:\n${result.files.map((file: string) => `• ${file}`).join('\n')}\n\nClick DOWNLOAD WEBSITE ZIP to receive the working website files.`)
      speak('Website build complete. Your download package is ready.', muted, 0)
    } catch (error) {
      setBuildError(error instanceof Error ? error.message : 'Website generation failed. Check the backend and try again.')
    } finally { setBuildBusy(false) }
  }

  if (showIntro) return <Intro muted={muted} onDone={finishIntro} onEnableVoice={enableVoice} />
  return <div className="app-shell"><ParticleField /><div className="scanlines" />
    <aside><div className="brand"><Reactor compact /><div><b>AEGIS AI</b><small>COMMAND SYSTEM</small></div></div>
      <nav>{['⌂ Command Center', '⚡ AI Agents', '◈ Missions', '◷ Mission History', '▣ Intelligence Reports'].map((x, i) => <a className={i === 0 ? 'nav-active' : ''} key={x}>{x}</a>)}</nav>
      <div className="fan-note">Portfolio-ready AI agent project.<br />Built with React, FastAPI and Gemini.</div>
    </aside>
    <section className="workspace">
      <header><div><small>SYSTEM STATUS</small><b><i /> ALL SYSTEMS OPERATIONAL</b></div><div className="header-actions"><span>{clock.toLocaleTimeString()}</span><button onClick={toggleMute}>{muted ? '🔇' : '🔊'}</button><button onClick={() => setSettings(true)}>⚙</button></div></header>
      <main className="dashboard"><div className="hero"><small>AEGIS COMMAND CENTER</small><h1>Welcome back, <em>Commander.</em></h1><p>Deploy specialized AI agents or assemble the complete team.</p></div>
      <section className="command-panel"><textarea value={mission} onChange={e => setMission(e.target.value)} placeholder="Describe any small website you want, or enter a normal mission…" /><div className="command-actions"><button className="secondary" onClick={assemble}>⚡ ASSEMBLE AGENTS</button><button className="primary" disabled={busy || !mission.trim()} onClick={execute}>{busy ? 'EXECUTING…' : 'EXECUTE MISSION →'}</button><button className="builder-button" disabled={buildBusy || !mission.trim()} onClick={buildWebsite}>{buildBusy ? 'BUILDING WEBSITE…' : '⚙ CREATE WEBSITE ZIP'}</button></div></section>
      <div className="section-title"><h2>AEGIS AGENTS</h2><span>{selected.length} DEPLOYED</span></div>
      <section className="agent-grid">{agents.map(a => <AgentCard key={a.id} agent={a} chosen={selected.includes(a.id)} onToggle={() => toggle(a.id)} />)}</section></main>
    </section>
    <aside className="mission-panel"><h2>ACTIVE MISSION</h2><p className="muted">{mission || 'Awaiting mission input…'}</p><div className="divider" /><h3>DEPLOYED TEAM</h3><div className="mini-team">{team.map(a => <span key={a.id} title={a.name} style={{ '--agent': a.color } as React.CSSProperties}>{a.symbol}</span>)}</div><div className="divider" /><h3>MISSION TIMELINE</h3><div className="timeline">{logs.length ? logs.map(x => <div key={x.id}><b>{x.agent}</b><p>{x.text}</p><small>{x.status}</small></div>) : <p className="muted">No activity yet.</p>}</div>{buildError && <><div className="divider" /><div className="builder-error">{buildError}</div></>}{websiteBuild && <><div className="divider" /><section className="builder-output"><small>UNIVERSAL WEBSITE BUILDER // {websiteBuild.mode.toUpperCase()} MODE</small><h3>{websiteBuild.title}</h3><p>{websiteBuild.summary}</p><div className="builder-files">{websiteBuild.files.map(file => <span key={file}>{file}</span>)}</div><a className="download-website" href={`${API}${websiteBuild.download_url}`}>DOWNLOAD WEBSITE ZIP ↓</a></section></>}{report && <><div className="divider" /><h3>FINAL REPORT</h3><pre>{report}</pre><button className="copy" onClick={() => navigator.clipboard.writeText(report)}>COPY REPORT</button></>}</aside>
    {settings && <div className="modal-backdrop"><div className="modal"><button className="modal-close" onClick={() => setSettings(false)}>×</button><h2>SYSTEM SETTINGS</h2><label><span>Voice narration</span><button onClick={toggleMute}>{muted ? 'OFF' : 'ON'}</button></label><label><span>Replay cinematic intro</span><button onClick={() => { setSettings(false); setShowIntro(true) }}>REPLAY</button></label><label><span>Clear mission activity</span><button onClick={() => { setLogs([]); setReport('') }}>CLEAR</button></label></div></div>}
  </div>
}

export default App
