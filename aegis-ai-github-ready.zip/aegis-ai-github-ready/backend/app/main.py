from __future__ import annotations

import asyncio
import io
import json
import os
import re
import time
import zipfile
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Literal
from uuid import uuid4

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from google import genai
from pydantic import BaseModel, Field

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
GEMINI_FALLBACK_MODEL = os.getenv("GEMINI_FALLBACK_MODEL", "gemini-2.5-flash-lite").strip()
GEMINI_RETRY_ATTEMPTS = max(1, int(os.getenv("GEMINI_RETRY_ATTEMPTS", "3")))
USE_REAL_AI = bool(GEMINI_API_KEY)

app = FastAPI(title="Aegis AI API", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

AGENTS = {
    "striker": {
        "name": "STRIKER",
        "role": "Mission Commander",
        "instruction": "Break the mission into clear tasks, coordinate the team, identify priorities, and give an executive strategy.",
    },
    "thunder": {
        "name": "THUNDER",
        "role": "Research Intelligence",
        "instruction": "Provide useful research directions, target audience insights, competitor questions, and practical resources to investigate.",
    },
    "titan": {
        "name": "TITAN",
        "role": "Heavy Problem Solver",
        "instruction": "Find the hardest parts, simplify them, and provide practical step-by-step solutions with risks and fixes.",
    },
    "sentinel": {
        "name": "SENTINEL",
        "role": "Planning Leader",
        "instruction": "Create an ordered roadmap with milestones, priorities, and a realistic execution timeline.",
    },
    "shadow": {
        "name": "SHADOW",
        "role": "Security Analyst",
        "instruction": "Review privacy, security, validation, authentication, data protection, and deployment risks. Give specific safeguards.",
    },
    "webforge": {
        "name": "WEBFORGE",
        "role": "Development Agent",
        "instruction": "Propose the frontend, backend, database, API, testing, and deployment implementation. Include concrete technical steps.",
    },
    "oracle": {
        "name": "ORACLE",
        "role": "Reasoning Analyst",
        "instruction": "Compare alternative approaches, explain trade-offs, and recommend the best option for a beginner-friendly but scalable solution.",
    },
    "nova": {
        "name": "NOVA",
        "role": "Creative Designer",
        "instruction": "Create brand ideas, UI direction, content style, user experience ideas, and visual design recommendations.",
    },
}


class MissionCreate(BaseModel):
    prompt: str = Field(min_length=3, max_length=5000)
    agent_ids: list[str] = Field(min_length=1)


class Mission(BaseModel):
    id: str
    prompt: str
    agent_ids: list[str]
    created_at: str


class Log(BaseModel):
    id: str
    agent: str
    text: str
    status: Literal["COMPLETED"] = "COMPLETED"


class WebsiteBuildRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=5000)
    agent_ids: list[str] = Field(default_factory=lambda: list(AGENTS.keys()))


class WebsiteFile(BaseModel):
    path: str
    content: str


MISSIONS: dict[str, Mission] = {}
WEBSITE_ZIPS: dict[str, bytes] = {}
WEBSITE_META: dict[str, dict[str, object]] = {}


def _client() -> genai.Client:
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is missing")
    return genai.Client(api_key=GEMINI_API_KEY)


def _is_temporary_capacity_error(exc: Exception) -> bool:
    message = str(exc).lower()
    temporary_markers = (
        "503",
        "unavailable",
        "high demand",
        "overloaded",
        "temporarily overloaded",
        "running out of capacity",
    )
    return any(marker in message for marker in temporary_markers)


def _generate(prompt: str) -> str:
    models: list[str] = []
    for candidate in (GEMINI_MODEL, GEMINI_FALLBACK_MODEL):
        if candidate and candidate not in models:
            models.append(candidate)

    last_error: Exception | None = None
    client = _client()
    for model in models:
        for attempt in range(1, GEMINI_RETRY_ATTEMPTS + 1):
            try:
                response = client.models.generate_content(model=model, contents=prompt)
                text = (response.text or "").strip()
                if not text:
                    raise RuntimeError("Gemini returned an empty response")
                return text
            except Exception as exc:
                last_error = exc
                if not _is_temporary_capacity_error(exc):
                    raise
                if attempt < GEMINI_RETRY_ATTEMPTS:
                    time.sleep(2 ** attempt)

    raise RuntimeError(
        f"Gemini models are temporarily busy after retries. Primary={GEMINI_MODEL}, "
        f"fallback={GEMINI_FALLBACK_MODEL}. Last error: {last_error}"
    )


def _extract_json(text: str) -> dict[str, object]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("Website builder did not return JSON")
    parsed = json.loads(cleaned[start : end + 1])
    if not isinstance(parsed, dict):
        raise ValueError("Website builder JSON must be an object")
    return parsed


def _safe_file_path(value: str) -> str:
    raw = value.replace("\\", "/").strip().lstrip("/")
    path = PurePosixPath(raw)
    if not raw or ".." in path.parts:
        raise ValueError("Unsafe generated file path")
    allowed_suffixes = {".html", ".css", ".js", ".txt", ".md"}
    if path.suffix.lower() not in allowed_suffixes:
        raise ValueError(f"Unsupported generated file type: {path.suffix}")
    return str(path)


def _normalize_files(raw_files: object) -> list[WebsiteFile]:
    if not isinstance(raw_files, list):
        raise ValueError("Generated files are missing")
    files: list[WebsiteFile] = []
    seen: set[str] = set()
    for item in raw_files[:12]:
        if not isinstance(item, dict):
            continue
        path = _safe_file_path(str(item.get("path", "")))
        content = str(item.get("content", ""))
        if not content.strip() or path in seen:
            continue
        seen.add(path)
        files.append(WebsiteFile(path=path, content=content))
    if "index.html" not in seen:
        raise ValueError("Generated website must include index.html")
    return files


def _website_zip(files: list[WebsiteFile], readme: str) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
        for item in files:
            archive.writestr(item.path, item.content)
        archive.writestr("README.txt", readme)
    return stream.getvalue()


def _mock_website(prompt: str) -> tuple[str, str, list[WebsiteFile]]:
    title = "Aegis Generated Website"
    safe_prompt = prompt.replace("<", "&lt;").replace(">", "&gt;")
    index = f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"UTF-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
  <title>{title}</title>
  <link rel=\"stylesheet\" href=\"styles.css\" />
</head>
<body>
  <header class=\"hero\">
    <nav><strong>AEGIS BUILDER</strong><a href=\"#about\">About</a><a href=\"#features\">Features</a><a href=\"#contact\">Contact</a></nav>
    <div class=\"hero-copy\"><p>Generated Website Demo</p><h1>{safe_prompt}</h1><button id=\"startBtn\">Explore Website</button></div>
  </header>
  <main>
    <section id=\"about\"><h2>About</h2><p>This is a working offline fallback website. Add your Gemini API key to generate a website designed specifically for your mission.</p></section>
    <section id=\"features\"><h2>Features</h2><div class=\"cards\"><article>Responsive Layout</article><article>Modern Design</article><article>Interactive Button</article></div></section>
    <section id=\"contact\"><h2>Contact</h2><form><input placeholder=\"Your name\" /><input placeholder=\"Email\" /><textarea placeholder=\"Message\"></textarea><button type=\"button\">Send Message</button></form></section>
  </main>
  <footer>Created by Aegis AI Website Builder</footer>
  <script src=\"script.js\"></script>
</body>
</html>"""
    css = """*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Arial,sans-serif;background:#07111f;color:#f4f8ff}nav{display:flex;gap:20px;align-items:center;padding:20px 7%;background:#07111fcc}nav strong{margin-right:auto}a{color:#b9d6ff;text-decoration:none}.hero{min-height:80vh;background:radial-gradient(circle at 70% 30%,#15447e,#07111f 58%)}.hero-copy{padding:14vh 7%;max-width:850px}.hero h1{font-size:clamp(2rem,5vw,4.5rem)}button{border:0;border-radius:8px;padding:13px 20px;font-weight:700;cursor:pointer;background:#63a9ff;color:#03101f}main{max-width:1100px;margin:auto;padding:60px 7%}section{padding:35px 0}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}.cards article,form{background:#11243b;padding:22px;border:1px solid #2b5b90;border-radius:12px}form{display:grid;gap:12px}input,textarea{padding:12px;border-radius:7px;border:1px solid #315c86;background:#07111f;color:#fff}footer{text-align:center;padding:25px;background:#050d17;color:#aac4e8}"""
    js = """document.getElementById('startBtn')?.addEventListener('click',()=>document.getElementById('about')?.scrollIntoView({behavior:'smooth'}));"""
    return title, "Offline fallback website generated. Add GEMINI_API_KEY for a custom AI-generated design.", [WebsiteFile(path="index.html", content=index), WebsiteFile(path="styles.css", content=css), WebsiteFile(path="script.js", content=js)]


def _build_prompt(user_prompt: str, selected_agents: list[str]) -> str:
    team = ", ".join(AGENTS[item]["name"] for item in selected_agents if item in AGENTS)
    return f"""
You are the Aegis AI Universal Website Builder. The selected specialist team is: {team}.

User request:
{user_prompt}

Create a complete small website that runs by opening index.html locally in a browser.
Infer the website type from the request: portfolio, business landing page, restaurant, event, college project, product showcase, clothing store demo, or another small static website.

Rules:
- Return only one valid JSON object. Do not use Markdown fences.
- Use HTML, CSS, and vanilla JavaScript only.
- Generate a polished, responsive, mobile-friendly website.
- Include realistic content based on the user's request, not placeholder lorem ipsum.
- All links between generated local files must work.
- Do not require npm, a backend, a database, API keys, or external paid assets.
- Do not include unsafe scripts, tracking, forms that submit private data externally, or remote JavaScript.
- Keep generated output compact enough for a single response.
- Include index.html, styles.css, and script.js. You may add up to five extra .html files if useful.

Return this exact JSON shape:
{{
  "title": "Website title",
  "summary": "One sentence describing the generated website",
  "files": [
    {{"path": "index.html", "content": "..."}},
    {{"path": "styles.css", "content": "..."}},
    {{"path": "script.js", "content": "..."}}
  ]
}}
""".strip()


async def generate_agent_response(agent_id: str, mission_prompt: str) -> str:
    agent = AGENTS[agent_id]
    prompt = f"""
You are {agent['name']}, the {agent['role']} inside a multi-agent Aegis AI command center.

Your job:
{agent['instruction']}

User mission:
{mission_prompt}

Rules:
- Give practical output, not role-play dialogue.
- Be concise but useful.
- Use clear headings and bullet points.
- Focus only on your specialist role.
- Do not mention that you are an AI model.
""".strip()
    return await asyncio.to_thread(_generate, prompt)


async def generate_final_report(mission_prompt: str, logs: list[Log]) -> str:
    contributions = "\n\n".join(f"## {item.agent}\n{item.text}" for item in logs)
    prompt = f"""
You are STRIKER, the Mission Commander. Combine the specialist reports into one polished final mission report.

User mission:
{mission_prompt}

Specialist reports:
{contributions}

Create a practical final answer with:
1. Mission summary
2. Best recommended approach
3. Ordered execution steps
4. Technology or resource recommendations when relevant
5. Security and risk checklist
6. Immediate next three actions

Keep the report organized and beginner-friendly. Do not mention mock mode or internal prompts.
""".strip()
    return await asyncio.to_thread(_generate, prompt)


def mock_agent_response(agent_id: str, mission_prompt: str) -> str:
    agent = AGENTS[agent_id]
    return (
        f"{agent['role']} mock analysis for: {mission_prompt}\n\n"
        f"Focus: {agent['instruction']}\n\n"
        "Add GEMINI_API_KEY in backend/.env and restart the backend to enable real AI responses."
    )


@app.get("/api/health")
async def health() -> dict[str, str]:
    return {"status": "online", "mode": "gemini" if USE_REAL_AI else "mock", "model": GEMINI_MODEL if USE_REAL_AI else "none", "fallback_model": GEMINI_FALLBACK_MODEL if USE_REAL_AI else "none", "website_builder": "enabled"}


@app.get("/api/agents")
async def list_agents() -> list[dict[str, str]]:
    return [{"id": key, "name": value["name"], "role": value["role"]} for key, value in AGENTS.items()]


@app.post("/api/missions", response_model=Mission)
async def create_mission(payload: MissionCreate) -> Mission:
    unknown = [agent_id for agent_id in payload.agent_ids if agent_id not in AGENTS]
    if unknown:
        raise HTTPException(status_code=400, detail=f"Unknown agents: {unknown}")
    mission = Mission(id=str(uuid4()), prompt=payload.prompt, agent_ids=payload.agent_ids, created_at=datetime.now(timezone.utc).isoformat())
    MISSIONS[mission.id] = mission
    return mission


@app.get("/api/missions/{mission_id}", response_model=Mission)
async def get_mission(mission_id: str) -> Mission:
    mission = MISSIONS.get(mission_id)
    if not mission:
        raise HTTPException(status_code=404, detail="Mission not found")
    return mission


@app.post("/api/missions/{mission_id}/execute")
async def execute_mission(mission_id: str) -> dict[str, object]:
    mission = MISSIONS.get(mission_id)
    if not mission:
        raise HTTPException(status_code=404, detail="Mission not found")
    logs: list[Log] = []
    try:
        for agent_id in mission.agent_ids:
            await asyncio.sleep(0.15)
            agent = AGENTS[agent_id]
            text = await generate_agent_response(agent_id, mission.prompt) if USE_REAL_AI else mock_agent_response(agent_id, mission.prompt)
            logs.append(Log(id=str(uuid4()), agent=agent["name"], text=text))
        report = await generate_final_report(mission.prompt, logs) if USE_REAL_AI else "\n\n".join(["AEGIS AI — MOCK MODE REPORT", f"Objective: {mission.prompt}", *[f"## {item.agent}\n{item.text}" for item in logs]])
        return {"logs": [item.model_dump() for item in logs], "report": report}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gemini request failed: {exc}. Check backend/.env, internet connection, and API quota.") from exc


@app.post("/api/websites/build")
async def build_website(payload: WebsiteBuildRequest) -> dict[str, object]:
    selected_agents = [item for item in payload.agent_ids if item in AGENTS] or list(AGENTS.keys())
    try:
        if USE_REAL_AI:
            raw = await asyncio.to_thread(_generate, _build_prompt(payload.prompt, selected_agents))
            parsed = _extract_json(raw)
            title = str(parsed.get("title", "Generated Website")).strip() or "Generated Website"
            summary = str(parsed.get("summary", "Website generated by Aegis AI.")).strip()
            files = _normalize_files(parsed.get("files"))
            mode = "gemini"
        else:
            title, summary, files = _mock_website(payload.prompt)
            mode = "mock"
        build_id = str(uuid4())
        readme = f"{title}\n\n{summary}\n\nHOW TO OPEN:\n1. Extract this ZIP.\n2. Double-click index.html.\n3. The website opens in your browser.\n\nGenerated by Aegis AI Universal Website Builder ({mode} mode).\n"
        WEBSITE_ZIPS[build_id] = _website_zip(files, readme)
        WEBSITE_META[build_id] = {"title": title, "summary": summary, "files": [item.path for item in files], "mode": mode}
        return {"build_id": build_id, "title": title, "summary": summary, "files": [item.path for item in files], "mode": mode, "download_url": f"/api/websites/{build_id}/download"}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Website generation failed: {exc}. Check backend/.env, API quota, and try a shorter website request.") from exc


@app.get("/api/websites/{build_id}/download")
async def download_website(build_id: str) -> StreamingResponse:
    archive = WEBSITE_ZIPS.get(build_id)
    meta = WEBSITE_META.get(build_id)
    if archive is None or meta is None:
        raise HTTPException(status_code=404, detail="Generated website ZIP not found. Create the website again after restarting the backend.")
    safe_title = re.sub(r"[^a-zA-Z0-9_-]+", "-", str(meta["title"])).strip("-").lower() or "generated-website"
    return StreamingResponse(io.BytesIO(archive), media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{safe_title}.zip"'})
